import firebase from "./firebaseConfig";

export const googleProvider = firebase.auth.GoogleAuthProvider();
